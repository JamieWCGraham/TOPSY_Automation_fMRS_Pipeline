
import time
from sikuli import *


def TicTocGenerator():
    # Generator that returns time differences
    ti = 0           # initial time
    tf = time.time() # final time
    while True:
        ti = tf
        tf = time.time()
        yield tf-ti # returns the time difference

TicToc = TicTocGenerator() # create an instance of the TicTocGen generator

# This will be the main function through which we define both tic() and toc()
def toc(tempBool=True):
    # Prints the time difference yielded by generator instance TicToc
    tempTimeInterval = next(TicToc)
    if tempBool:
        print( "Elapsed time: %f seconds.\n" %tempTimeInterval )

def tic():
    # Records a time in TicToc, marks the beginning of a time interval
    toc(False)

tic()

global screen
screen = Screen(0)


# START OF AUTOMATION CODE!! 

# This is an automation code that seeks to automate the fMRS pipeline for Dr. Palaniyappan's Lab.


# Adjust settings
Settings.MoveMouseDelay = 0.1
Settings.TypeDelay = 0

# User input prompts 

global h
h = "/Users/jamiegraham/Documents/PipelineFullWindows.sikuli/"


global edit
edit="N"     # here we are initializing an important variable, this accounts for whether we have adjusted for voxel positioning or not.



# here we need to change this part of the code to the pathway for our spectra datasets" 

file_path = "/Users/jamiegraham/Documents/fMRS/PETMRFIT/DIME"

# defining some useful automation functions 

      
def waitP(file,thresh,forever):
    if forever:
        screen.wait(Pattern(h + file).similar(thresh),3600)
    else:
        try:
            screen.wait(Pattern(h + file).similar(thresh))
        except:
            screen.wait(Pattern(h + file).similar(thresh),3600)
        

      
def clickP(file,thresh,forever):
    if forever:
        screen.click(Pattern(h + file).similar(thresh),3600)
    else:
        try:
            screen.click(Pattern(h + file).similar(thresh))
        except:
            screen.click(Pattern(h + file).similar(thresh),3600)
            
            
def click2P(file,thresh,forever):
    if forever:
        screen.doubleClick(Pattern(h + file).similar(thresh),3600)
    else:
        try:
            screen.doubleClick(Pattern(h + file).similar(thresh))
        except:
            screen.doubleClick(Pattern(h + file).similar(thresh),3600)
            
            
def click2RP(file,thresh,forever):
    if forever:
        screen.rightClick(Pattern(h + file).similar(thresh),3600)
    else:
        try:
            screen.rightClick(Pattern(h + file).similar(thresh))
        except:
            screen.rightClick(Pattern(h + file).similar(thresh),3600)
            
            
def existsP(file,thresh):
    screen.exists(Pattern(h + file).similar(thresh))


def waitclickP(file,thresh,forever):
    waitP(file,thresh,forever)
    clickP(file,thresh,forever)

def wait2clickP(file,thresh,forever):
    waitP(file,thresh,forever)
    click2P(file,thresh,forever)

def wait2rightclickP(file,thresh,forever):
    waitP(file,thresh,forever)
    click2RP(file,thresh,forever)

def waitclickPTO(file,thresh,forever,x_coord,y_coord):
    waitP(file,thresh,forever)
    if forever:
        screen.click(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord),3600)
    else:
        try:
            screen.click(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord))
        except:
            screen.click(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord),3600)
        
def wait2clickPTO(file,thresh,forever,x_coord,y_coord):
    waitP(file,thresh,forever)
    if forever:
        screen.doubleClick(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord),3600)
    else:
        try:
            screen.doubleClick(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord))
        except:
            screen.doubleClick(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord),3600)

def closeNow(): 
    type(Key.F4,Key.ALT)
    type(Key.ENTER)
    type(Key.ENTER)



for i in range(22,34):
    wait(1)
    paste("./sim2fitman -ow /Users/jamiegraham/Documents/STEM/fMRS/PETMRFIT/CONTROLS/NEUROPETC"+ str(i) + "FRONTAL_finished_sup.rda -scale -bc -if -quecc  400  0.000 /Users/jamiegraham/Documents/STEM/fMRS/PETMRFIT/CONTROLS/NEUROPETC" + str(i) + "FRONTAL_uns.rda -norm -rscale -rbc -rif /Users/jamiegraham/Documents/STEM/fMRS/PETMRFIT/CONTROLS/NEUROPETC" + str(i) + "FRONTAL_finished_test")
    wait(1)
    type(Key.ENTER)
    wait(1)
    paste("1")
    wait(1)
    type(Key.ENTER)
    wait(1)
    paste("1")
    wait(1)
    type(Key.ENTER)



for i in range(21,34):
    waitclickP("File.png",0.8,1)
    waitclickP("Data.png",0.8,1)
    waitclickP("text-box.png",0.8,1)
    wait(1)
    type("/Users/jamiegraham/Documents/STEM/fMRS/PETMRFIT/CONTROLS/NEUROPETC" + str(i) + "FRONTAL_finished_test_s.dat")
    wait(1)
    wait2clickP("Ok.png",0.8,1)
    waitclickP("Arithmetic.png",0.8,1)
    waitclickP("hsvd_water_removal.png",0.8,0.1)
    waitclickP("Ok2.png",0.8,1)   
    waitclickP("File.png",0.8,1)
    wait(1)
    waitclickP("1647370115055.png",0.8,1)
    wait(1)
    waitclickP("text-box.png",0.8,1)
    type("/Users/jamiegraham/Documents/STEM/fMRS/PETMRFIT/CONTROLS/NEUROPETC" + str(i) + "FRONTAL_sup.dat")
    wait2clickP("Ok.png",0.8,1)
    waitclickPTO("view_arithmetic.png",0.8,1,-30,0)
    wait2clickP("clear_all_windows.png",0.8,1)
    wait(1)
    
    
    
    




