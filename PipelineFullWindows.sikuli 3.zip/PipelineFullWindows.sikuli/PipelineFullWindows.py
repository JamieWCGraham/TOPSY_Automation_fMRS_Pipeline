import time
from sikuli import *


def TicTocGenerator():
    # Generator that returns time differences
    ti = 0           # initial time
    tf = time.time() # final time
    while True:
        ti = tf
        tf = time.time()
        yield tf-ti # returns the time difference

TicToc = TicTocGenerator() # create an instance of the TicTocGen generator

# This will be the main function through which we define both tic() and toc()
def toc(tempBool=True):
    # Prints the time difference yielded by generator instance TicToc
    tempTimeInterval = next(TicToc)
    if tempBool:
        print( "Elapsed time: %f seconds.\n" %tempTimeInterval )

def tic():
    # Records a time in TicToc, marks the beginning of a time interval
    toc(False)

tic()



# START OF AUTOMATION CODE!! 

# This is an automation code that seeks to automate the fMRS pipeline for Dr. Palaniyappan's Lab.


# Adjust settings
Settings.MoveMouseDelay = 0.1
Settings.TypeDelay = 0

# User input prompts 

num_of_spec = int(input("# of spectra?"))
date = int(input("year/date of acquisition (YYYYMMDD)"))
id = int(input("subject ID"))
flawed = str(input("flawed dataset (Y or N)? (voxel positioning bug)"))
inner_re_edit = "N"    # don't worry about this, just an initialization of a parameter we'll need later

global h
h = "C:/Users/Peter Jeon/Desktop/PipelineFullWindows.sikuli/PipelineFullWindows.sikuli/"

global screen
screen = Screen(1)

global edit
edit="N"     # here we are initializing an important variable, this accounts for whether we have adjusted for voxel positioning or not.





if flawed == "Y":
    flawed_coords = []
    flawed_coords_x = round(float(input("Flawed coordinates sag?")),1)
    flawed_coords_y = round(float(input("Flawed coordinates cor?")),1)
    flawed_coords_z = round(float(input("Flawed coordinates tra?")),1)
    flawed_coords = [flawed_coords_x, flawed_coords_y, flawed_coords_z]

# here we need to change this part of the code to the pathway for our spectra datasets" 

file_path = "/home/pjeon/Documents/"

# defining some useful automation functions 





      
def waitP(file,thresh,forever):
    if forever:
        screen.wait(Pattern(h + file).similar(thresh),FOREVER)
    else:
        screen.wait(Pattern(h + file).similar(thresh))

      
def clickP(file,thresh,forever):
    if forever:
        screen.click(Pattern(h + file).similar(thresh),FOREVER)
    else:
        screen.click(Pattern(h + file).similar(thresh))

def click2P(file,thresh,forever):
    if forever:
        screen.doubleClick(Pattern(h + file).similar(thresh),FOREVER)
    else:
        screen.doubleClick(Pattern(h + file).similar(thresh))

def click2RP(file,thresh,forever):
    if forever:
        screen.rightClick(Pattern(h + file).similar(thresh),FOREVER)
    else:
        screen.rightClick(Pattern(h + file).similar(thresh))

def existsP(file,thresh):
    screen.exists(Pattern(h + file).similar(thresh))


def waitclickP(file,thresh,forever):
    waitP(file,thresh,forever)
    clickP(file,thresh,forever)

def wait2clickP(file,thresh,forever):
    waitP(file,thresh,forever)
    click2P(file,thresh,forever)

def wait2rightclickP(file,thresh,forever):
    waitP(file,thresh,forever)
    click2RP(file,thresh,forever)

def waitclickPTO(file,thresh,forever,x_coord,y_coord):
    waitP(file,thresh,forever)
    if forever:
        screen.click(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord),FOREVER)
    else:
        screen.click(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord))

        
def wait2clickPTO(file,thresh,forever,x_coord,y_coord):
    waitP(file,thresh,forever)
    if forever:
        screen.doubleClick(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord),FOREVER)
    else:
        screen.doubleClick(Pattern(h + file).similar(thresh).targetOffset(x_coord,y_coord))
    





def terminal():
    type("n", Key.CTRL)
    wait2rightclickP("MAGIQ.png",0.8,0)
    waitclickP("OpenT.png",0.8,0)

def closeNow(): 
    type(Key.F4,Key.ALT)
    type(Key.ENTER)
    type(Key.ENTER)

def voxel_adjust():

    terminal()
    wait(3)
    paste("open -a 'Visual Studio Code' dataclasses.py")
    type(Key.ENTER)
    if existsP("Dataclasses.png",0.8,0):
        waitclickP("Dataclasses.png",0.8,0)
    else:
        wait(5)
    type("f", Key.CTRL)
    type("fid_pvec")
    #waitclickP(Pattern("contact.png").similar(0.71).targetOffset(-31,0)) # fix this
    waitclickPTO("#contact.png",0.71,0,-31,0)
    type(Key.DOWN)
    paste("fid_pvec = np.array(" + str(flawed_coords) + ",'f8')")  
    type("s",Key.CMD)
    type("w",Key.CMD)
    type("w",Key.CMD)               
    terminal()
    global edit         
    edit="Y"

    

def voxel_de_adjust():
    
    terminal()
    wait(3)
    paste("open -a 'Visual Studio Code' dataclasses.py")
    type(Key.ENTER)
    if existsP("Dataclasses.png",0.8,0):
        waitclickP("Dataclasses.png",0.8,0)
    else:
        wait(5)
    type("f", Key.CMD)
    type("fid_pvec")
    waitclickPTO("#contact.png",0.71,0,-31,0)
    type(Key.DOWN)
    for i in range(46):
        type(Key.RIGHT)
    for i in range(46):
        type(Key.BACKSPACE)
    type("s",Key.CMD)
    type("q",Key.CMD)            
    hyper()
    global inner_re_edit 
    inner_re_edit = "Y"

def searchNow(path_of_file):
    type("l", Key.CTRL)
    type(Key.BACKSPACE)
    type(path_of_file)
    type(Key.ENTER)
    wait(1)
    type(Key.ENTER)
    


# just a little logic here for file naming, we want a leading 0 for ID's less than 100. (e.g TOPSY079) for id 79)
    
if id <= 99:
    file_title = "TOPSY0" +  str(id) + "_" + str(date)
else:
    file_title = "TOPSY" +  str(id) + "_" + str(date)



if flawed == "Y":
    terminal()
    voxel_adjust()   # if dataset is flawed, this will adjust for voxel bug, and set edit="Y"


        


# this iterates over all 96 spectra and automatically carries out the fitman and barstool protocol for each
for spec_num in range(1,(num_of_spec + 1)):
    try:
        terminal()
        if existsP("terminalpink.png",0.8,0):
            clickP("terminalpink.png",0.8,0)
        
        paste("python" + Key.SPACE + "fitman.py")
        type(Key.ENTER)
        
        waitclickP("Ok.png",0.77,1)
        waitclickP("Ok.png",0.77,1)
        waitclickP("options.png",0.71,1)
        waitclickP("set_default_dir.png",0.71,1)
        waitclickP("browse.png",0.81,1)
        wait2clickPTO("Directory.png",0.73,1,-4,23)
        
        type(Key.BACKSPACE)
        
        type(file_path + file_title + "/")
        
        type(Key.ENTER)
       
        waitclickP("Ok.png",0.77,1)

        waitclickP("Ok.png",0.71,1)
        
        waitclickP("File.png",0.81,1)

        waitclickP("convert_raw_data.png",0.71,0)
        
        waitclickP("Siemens.png",0.77,0)

        wait2clickP("input_filename.png",0.83,0)

        
        type(file_path + file_title +  "/" + str(spec_num) + "/" + file_title + "_sup.rda")
        
        
        wait2clickP("output_filename.png",0.89,0)
        
        
        type(file_path + file_title +  "/" + str(spec_num) + "/" + file_title )
        
        
        waitclickPTO("baseline_correction.png",0.89,0,41,0)

        waitclick("Quecc.png",0.79,0)

        wait2clickP("reference_file.png",0.83,0)
        
        type(file_path + file_title +  "/" + str(spec_num) + "/" + file_title + "_uns.rda")
        
        
        waitclickPTO("baseline_correction.png",0.79,0,15,0)
        
        wait2clickP("time_delay.png",0.76,0)

        
        for i in range(7) :
            type(Key.BACKSPACE)
        
        type("0")


        wait2clickP("Ok2.png",0.81,0)
        waitclickPTO("Gain.png",0.76,0,41,-2)

        
        type("1" + Key.ENTER)
        
        waitclickPTO("Gain.png",0.76,0,41,-2)
        
        type("1" + Key.ENTER)

       
        waitclickP("fitman_suite.png",0.8,0)
        

        waitclickP("File.png",0.81,0)
       

        waitclickP("Data.png",0.78,0)
        
        waitclickPTO("Directories.png",0.83,0,5,9)
        
        for i in range(1 + spec_num):
            type(Key.DOWN)
        
        type(Key.ENTER)
        

        wait2clickP("text-box.png",0.75,0)
        
        
        type(file_title + "_sup.dat" + Key.ENTER)


        waitclickP("Arithmetic.png",0.75,0)

        waitclickP("hsvd_water_removal.png",0.76,0)


        waitclickP("Ok2.png",0.74,0)


#   ENTER EXTRA STUFF HERE FOR FITMAN AND ALSO maybe uns after this... 
        
        #waitclickPTO("view_arithmetic.png",0.72,0,-41,1)


       # waitclickP("clear_all_windows.png",0.73,0)
        

        waitclickP("File.png",0.81,0)

        
        

        waitclickP("Contraints.png",0.78,0)
        
        waitclickPTO("Directories.png",0.83,0,5,9)
        
        for i in range(1 + spec_num):
            type(Key.DOWN)
        
        type(Key.ENTER)
        
        wait2clickP("text-box.png",0.75,0)
        
        type("sLASER_sim_results_noMM_te100.cst" + Key.ENTER)
        
        
       
        waitclickP("File.png",0.81,0)
        


        waitclickP("Guess.png",0.99,0)
        
        waitclickPTO("Directories.png",0.83,0,5,9)
        
        for i in range(1 + spec_num):
            type(Key.DOWN)
        
        type(Key.ENTER)
        
        wait2clickP("text-box.png",0.75,0)
        
        type("sLASER_sim_results.ges" + Key.ENTER)
        
        waitclickP("File.png",0.81,0)


        waitclickP("generate_fit.png",0.8,0)
        
        # BARSTOOL NOW!!! 
        
        
        closeNow()
        
        terminal()
    
        paste("python" + Key.SPACE + "barstool.py")
        type(Key.ENTER)
        
        
        wait(1)
 

        waitclickP("Barstool.py",0.92,1)

        

        waitclickP("set_working_directory.png",0.77,0)
        
                
       

        searchNow(file_path + file_title + "/" + str(spec_num) + "/")
        
       

        waitclickP("load_output_files.png",0.8,0)

        
        

        
        type(Key.DOWN + Key.ENTER)
        
        wait2clickP("confirm_study_ids.png",0.79,0)
        wait2clickPTO("csv.png",0.78,0,29,0)

        
        for i in range(7):
            type(Key.BACKSPACE)
        
        paste(file_title + "_" + str(spec_num) + ".csv")

       
       

        wait2clickP("confirm_save_file_name.png",0.75,0)
        wait2click("calculate_amplitudes_and_crlbs.png",0.8,0)
        
        
        # Brain Extraction 

        wait2click("brain_extraction.png",0.78,0)
        wait2click("select_image_files.png",0.74,0)
        wait2click("search_box.png",0.71,0)

       

        searchNow(file_path + file_title + "/" + str(spec_num) + "/" + file_title + ".nii.gz")


        
        wait2clickP("reorient_images.png",0.72,0)
        waitclickP("launch_fsleyes.png",0.72,0)
        

        waitP("Location.png",0.72,1)
        
        wait(5)
       
        wait2clickPTO("Location.png",0.72,0,-10,6)        
        
        type("c", KEY_CMD)
        x = Env.getClipboard()
  
        wait2clickPTO("Location2.png",0.8,0,-5,4)
        
        type("c", KEY_CMD)
        y = Env.getClipboard()
        
        wait2clickPTO("Location2.png",0.8,0,-9,29)
        
        type("c",KEY_CMD)
        z = Env.getClipboard()
        
        closeNow()
        
        wait2clickPTO("x-y-z.png",0.73,0,-381,0)
        
        type(x)
        
        wait2clickPTO("x-y-z.png",0.73,0,26,0)
        
        type(y)
         
        wait2clickPTO("x-y-z.png",0.73,0,432,0)
        
        type(z)
        
        wait2clickP("confirm_brain_isocenter.png",0.73,0)
        
        
        wait2clickPTO("confirm_test_thresholds.png",0.82,0,-163,-3)

        
        for i in range(40):
            type(Key.BACKSPACE)
        
        type("0.2")
        

        wait2clickP("confirm_test_thresholds.png",0.82,0)

        wait2clickP("run_test_fsl.png",0.71,0)


        waitP("check_test_thresholds.png",0.73,1)


        wait2clickP("check_test_thresholds.png",0.73,0)

        waitP("Fsleyes.png",0.8,1)

        
        wait(10)
        
        closeNow()
        
        wait2clickP("confirm_intensity_threshold.png",0.73,0)


        waitP("run_brain_extraction.png",0.71,1)
        
        wait2clickP("run_brain_extraction.png",0.71,0)
        

        wait(4) 
        
 
        wait2clickP("brain_segmentation.png",0.72,0)
        

        wait2clickP("select_brain_extracted.png",0.71,0)
        
        
        wait2clickP("search_box.png",0.7,0)
        
        

        searchNow(file_path + file_title + "/" + str(spec_num) + "/" + file_title + "_std_brain.nii.gz")
        
        wait2clickP("confirm_image_type.png",0.71,0)
        

        wait2clickP("confirm_fast_settings.png",0.71,0)

        if spec_num == 1:

            tic()
        

            wait2clickP("run_pvs.png",0.74,0)
            

            waitP("run_pvs.png",0.71,1)

            toc()
        else: 
            # this part is a little code that copies the Partial Volume Segmentation file for the first spectra to the current spec_num folder          
            
            wait2clickP("windows.png",0.8,0)
            type("l", Key.CTRL)
            paste("/Applications/Utilities/Terminal")
            type(Key.ENTER)
            wait(1)
            type("o",Key.CMD)
            type("n",Key.CMD)
            paste("cp -R " + file_path + file_title + "/" + "1" + "/" + file_title + "_std_brain_seg.nii.gz " + file_path + file_title + "/" + str(spec_num))
            type(Key.ENTER)
            paste("cd " + file_path + file_title + "/" + str(spec_num))
            type(Key.ENTER)
            paste("ls -a")
            type(Key.ENTER)
            type("w",Key.CMD)
        
            waitP("Barstool.py",0.92,1)
        
       
            waitclickP("Barstool.py",0.92,0)
            



        waitP("set_parameters.png",0.71,1)
        



        wait2clickP("set_parameters.png",0.71,0)

       


        wait2clickP("Lead.png",0.71,0)
        

        waitclickP("metab7T.png",0.71,0)

        
        type(Key.ENTER)
        
       


        if existsP("metab7T.png",0.71):
            waitclickP("metab7T.png",0.71,0)
            type(Key.ENTER)
        else:
            print("all good")

            
      

        wait2clickP("confirm_quantification_parameters.png",0.71,0)

        
        


        wait2clickP("quantify_metabolites.png",0.71,0)

        
        

        wait2clickP("load_suppressed_output_files.png",0.71,0)

        
       
        
        type(Key.DOWN + Key.ENTER)
        


        wait2clickPTO("csv.png",0.78,0,29,0)
        
        for i in range(7):
            type(Key.BACKSPACE)
        
        paste(file_title + "_" + str(spec_num) + ".csv")


       
        wait2clickP("confirm_save_file_name.png",0.75,0)
        
        wait(3)
        

        wait2clickP("run_quantification.png",0.71,0)
    
        wait(10)
        
        closeNow()
        
        terminal()
        
    except: 
        if edit=="Y":
            voxel_de_adjust()


if ((flawed=="Y") and (inner_re_edit != "Y")):
    voxel_de_adjust()


toc() # returns "Elapsed time: 5.00 seconds."



